Cable Clip 20mm - 3D Print STL File

ICINDEKILER
  cable-clip-20mm.stl   - baski dosyasi
  README.txt - bu dosya

OLCULER
  28 mm x 36.11 mm x 18 mm
  Hacim: 6.246 cm3

ONERILEN BASKI AYARLARI
  Katman yuksekligi : 0.20 mm
  Duvar            : 3 hat
  Dolgu            : %25 (fonksiyonel parca icin %40)
  Destek           : gerekmiyor
  Yataga yapisma   : brim onerilir
  Malzeme          : PLA / PETG

NOTLAR
  - Model su gecirmez (watertight) olarak kontrol edilmistir.
  - Sikilik ihtiyacina gore yazicinin tolerans farkini +-0.1 mm hesaba katin.

LISANS
  Kisisel kullanim. Basilmis parcalari satmak icin ticari lisans gerekir.

Orijinal parametrik tasarim.
