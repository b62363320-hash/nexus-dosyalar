Cable Clip 32mm - 3D Print STL File

ICINDEKILER
  cable-clip-32mm.stl   - baski dosyasi
  README.txt - bu dosya

OLCULER
  41 mm x 47.66 mm x 22 mm
  Hacim: 11.632 cm3

ONERILEN BASKI AYARLARI
  Katman yuksekligi : 0.20 mm
  Duvar            : 3 hat
  Dolgu            : %25 (fonksiyonel parca icin %40)
  Destek           : gerekmiyor
  Yataga yapisma   : brim onerilir
  Malzeme          : PLA / PETG

NOTLAR
  - Model su gecirmez (watertight) olarak kontrol edilmistir.
  - Sikilik ihtiyacina gore yazicinin tolerans farkini +-0.1 mm hesaba katin.

LISANS
  Kisisel kullanim. Basilmis parcalari satmak icin ticari lisans gerekir.

Orijinal parametrik tasarim.
